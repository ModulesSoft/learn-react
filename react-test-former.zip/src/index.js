import {goodbye,hello} from "./lib";
import React from 'react'
import  {render} from 'react-dom'
import 'bootstrap/dist/css/bootstrap.css'
import Counter from "./components/counter.jsx"

// const {createElement} = React
// const {render} = ReactDOM

/*const style = {
    backgroundColor: 'orange',
    color: 'white',
    fontFamily: 'verdana'
}
const title = React.createElement(
    'h1',
    {id: 'title',className: 'header',style:style},
    'Hello world'
)*/
render(
<Counter/>,
document.getElementById('react-container')
)
registerServiceWorker();
import React from 'react';

function Counter() {
    let x = 0;
    let y = 1;
    x = y;
    return (<div>
        <h1>hello world</h1>
        <button className="m-2 btn-danger"></button>
    </div>);
}

export default Counter;